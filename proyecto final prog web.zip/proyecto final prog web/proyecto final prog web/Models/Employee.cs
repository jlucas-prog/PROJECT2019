﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace proyectofinalprogweb.Models
{
    public class Employee
    {
        [Key]
        public string Nombre { get; set; }
        [Column(TypeName = "varchar(250)")]
        [Required(ErrorMessage ="This fiel is required")]
        [DisplayName("Full Name")]
        public string Apellido { get; set; }
        [Column(TypeName = "varchar(10)")]
        [DisplayName("Emp.Code")]
        public int Cedula { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string Direccion { get; set; }
        [Column(TypeName = "varchar(250)")]
        [DisplayName("Office Location")]
        public int Telefono { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string Sexo { get; set; }
        [Column(TypeName = "varchar(250)")]
        public int Edad { get; set; }
        [Column(TypeName = "nvarchar(250)")]

        public string Fecha_Nacimiento { get; set; }
        [Column(TypeName = "varchar(250)")]
        public string Afiliados { get; set; }
     

    }

}
