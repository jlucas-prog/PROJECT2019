﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace proyectofinalprogweb.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Nombre = table.Column<string>(nullable: false),
                    Apellido = table.Column<string>(type: "varchar(250)", nullable: false),
                    Cedula = table.Column<string>(type: "varchar(10)", nullable: false),
                    Direccion = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    Telefono = table.Column<string>(type: "varchar(250)", nullable: false),
                    Sexo = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    Edad = table.Column<string>(type: "varchar(250)", nullable: false),
                    Fecha_Nacimiento = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    Afiliados = table.Column<string>(type: "varchar(250)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Nombre);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
